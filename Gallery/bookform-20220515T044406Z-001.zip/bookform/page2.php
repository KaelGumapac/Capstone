<?php include 'navbar.php'; ?>
    
    <link rel="stylesheet" href="style.css?v=<?php echo time();?>">
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
    <title>Document</title>

 
    <form id = "tae" class="hotel-reservation-form" method="post" action="">
			<h1><img id="logo"src="maybe.png"></i><br>Complete your booking</h1>
			<div class="fields">
				<!-- Input Elements -->
                <div class="wrapper">
                    <div>
                        <label for="arrival">Check In date:</label>
                        <div class="field">
                            <input id="arrival" type="date" name="arrival" required>
                        </div>
                    </div>
                    <div class="gap"></div>
                    <div>
                        <label for="departure">Check Out date:</label>
                        <div class="field">
                            <input id="departure" type="date" name="departure" required>
                        </div>
                    </div>
                </div>
                <div class="wrapper">
                    <div>
                        <label for="first_name">Guest Name</label>
                        <div class="field">
                            <i class="fas fa-user"></i>
                            <input id="first_name" type="text" name="first_name" placeholder="First Name" required>
                        </div>
                    </div>
                </div>
                <label for="email">Email</label>
                <div class="field">
                    <i class="fas fa-envelope"></i>
                    <input id="email" type="email" name="email" placeholder="Your Email" required>
                </div>
                <div class="wrapper">
                    <div>
                        <label for="arrival">Phone</label>
                        <div class="field">
                        <i class="fas fa-phone"></i>
                        <input id="first_name" type="text" name="numbah" placeholder="numbah" required>
                        </div>
                    </div>
                    <div class="gap"></div>
                    <div>
                        <label for="departure">Room</label>
                        <div class="field">
                        <i class='bx bx-hotel'></i>
                        <input id="first_name" type="text" name="room" placeholder="room" required>
                        </div>
                    </div>
                </div>
                <label>Total:</label>
                <div class="field"><i><span>&#8369;</span></i>
                    <input id="total" type="text" name="total" value="1,000" readonly>
                <br>
                </div>
                <h5>Payment Method:</h5>
                <div class="method">
                <p>Gcash:</p>
                <img src="gcash2.png" alt="" srcset="">
                </div>
                <p>Paypal: </p>
                <!-- PayPal Logo --><table border="0" cellpadding="10" cellspacing="0" align="center"><tr><td align="center"></td></tr><tr><td align="center"><a href="https://www.paypal.com/ph/webapps/mpp/paypal-popup" title="How PayPal Works" onclick="javascript:window.open('https://www.paypal.com/ph/webapps/mpp/paypal-popup','WIPaypal','toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=1060, height=700'); return false;"><img src="https://www.paypalobjects.com/webstatic/mktg/logo/PP_AcceptanceMarkTray-NoDiscover_243x40.png" alt="Buy now with PayPal" /></a></td></tr></table><!-- PayPal Logo -->
                        </div>
					</div>
                </div>
                </div>
			</div>
		</form>
    
</body>
</html>
