<?php include 'navbar.php';?>

        <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
		<title>Hotel Reservation Form</title>
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
		<link rel="stylesheet" href="style.css?v=<?php echo time();?>">
        
        <div class="room">
            <center><img src="aj.png"></center>
            <h3>Twinsharing Room</h3>
            <p>&emsp;&emsp;<i class='bx bx-check-circle'></i>&ensp;2 Single beds</p>
            <p>&emsp;&emsp;<i class='bx bx-check-circle'></i>&ensp;2 guests&emsp;<i class='bx bx-check-circle'></i>&ensp;1 Bathroom</p>
            <p>&emsp;&emsp;<i class='bx bx-check-circle'></i>&ensp;Complimentary Breakfast for 2 persons</p>
            <p><i class='bx bx-info-circle' ></i>&ensp;2 PM (Check in) - 12 Noon (Check out)</p>
            <p><i class='bx bx-info-circle' ></i>&ensp;370 PHP charge for extra person</p>
            <p><i class='bx bx-info-circle' ></i>&ensp;Pay today</p>
            <p id = "bottomright">₱ 6000</p>
        </div>


		<form id = "tae" class="hotel-reservation-form" method="post" action="page2.php">
			<h1><i class="far fa-calendar-alt"></i>Hotel Reservation Form</h1>
			<div class="fields">
				<!-- Input Elements -->
                <div class="wrapper">
                    <div>
                        <label for="arrival">Check In</label>
                        <div class="field">
                            <input id="arrival" type="date" name="arrival" required>
                        </div>
                    </div>
                    <div class="gap"></div>
                    <div>
                        <label for="departure">Check Out</label>
                        <div class="field">
                            <input id="departure" type="date" name="departure" required>
                        </div>
                    </div>
                </div>
                <div class="wrapper">
                    <div>
                        <label for="first_name">First Name</label>
                        <div class="field">
                            <i class="fas fa-user"></i>
                            <input id="first_name" type="text" name="first_name" placeholder="First Name" required>
                        </div>
                    </div>
                    <div class="gap"></div>
                    <div>
                        <label for="last_name">Last Name</label>
                        <div class="field">
                            <i class="fas fa-user"></i>
                            <input id="last_name" type="text" name="last_name" placeholder="Last Name" required>
                        </div>
                    </div>
                </div>
                <label for="email">Email</label>
                <div class="field">
                    <i class="fas fa-envelope"></i>
                    <input id="email" type="email" name="email" placeholder="Your Email" required>
                </div>
                <label for="email">Confirm Email</label>
                <div class="field">
                    <i class="fas fa-envelope"></i>
                    <input id="email" type="email" name="email" placeholder="Confirm Email" required>
                </div>
                <label for="phone">Phone</label>
                <div class="field">
                    <i class="fas fa-phone"></i>
                    <input id="phone" type="tel" name="phone" placeholder="Your Phone Number" required>
                </div>
                <div class="wrapper">
                    <div>
                        <label for="adults">Adults</label>
                        <div class="field">
                            <select id="adults" name="adults" required>
                                <option disabled selected value="">--</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>
                        </div>
                    </div>
                    <div class="gap"></div>
                    <div>
                        <label for="children">Children</label>
                        <div class="field">
                            <select id="children" name="children" required>
                                <option disabled selected value="">--</option>
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>
                        </div>   
                    </div>
                </div>
                <input type="checkbox" id="vehicle2" name="vehicle2" value="Car" required>
                <label for="vehicle2"> I have read and agree to the terms and conditions</label><br>
                <input type="submit" value="Proceed to payment">

			</div>
		</form>
	</body>
</html>